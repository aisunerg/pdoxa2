<?php

namespace App\Http\Controllers;

use App\Models\Day;
use Illuminate\Http\Request;

class DayController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $day = new Day();

        $day->name = $request->name;
        $day->number = $request->number;
        $day->scheme_day_id = $request->schemeday;
        $day->save();

        return to_route('schemeday.show', $request->schemeday)->with('message', 'Dia: "'.$day->name.'", Agregado con Exito!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Day $day)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Day $day)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Day $day)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Day $day)
    {
        $dayB = $day->scheme_day_id;
        $day->delete();
        return to_route('schemeday.show', $dayB)->with('message', 'Dia eliminado con exito.');
    }
}
