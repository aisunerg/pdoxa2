<script setup>
    import MyLayout from '@/Layouts/MyLayout.vue';
    import { Head, Link } from '@inertiajs/vue3';

    const props = defineProps({
        project: {
            type: Object,
            default: null
        },
        subjects: {
            type: Object,
            default: null
        }

    });

    let semestres = [1,2,3,4,5,6,7,8,9,10];

</script>

<template>
  <Head title="MiDashBoard"/>
  <MyLayout :project="project">
    <template #header>
      <div class="" >
        Ver {{ $page.props.sProject.name }}
      </div>
    </template>
    <div class="border-b-2 border-black shadow-none mb-2"></div>

    <div class="overflow-auto w-full" style="height: 83%;">
        <table class="w-full table-auto border-collapse" v-for="semestre in semestres">
            <thead>
                <tr class="no-screen"><!-- Encabezado -->
                    <td colspan="9">    
                        <div id="" class="flex flex-row">
                            <div id="inline "><img src="/img/unerg.png" alt="logo UNERG" class="w-24"></div>
                            <div id="inline mx-2">
                                <span class="block font-bold text-xs">Universidad Nacional Experimental Rómulo Gallegos</span>
                                <span class="block font-bold text-xs">Area de Ingeniería de Sistémas</span>
                                <span class="block font-bold text-xs">Programa: Ingeniería en Informática</span>
                                <span class="block font-bold text-xs">Lapso Académico: 2016-1</span>
                                <span class="block font-bold text-xs">Comisión de Horarios Académicos</span>
                            </div>
                        </div>
                    </td>
                </tr>

                <tr class="no-screen"><!-- Titulo -->
                    <td colspan="9">
                        <span class="block text-center font-bold">Resumen de Horarios Semanales</span>
                        <span class="block text-center font-bold">{{ semestre }}° Semestre</span>
                    </td>
                </tr>

                <tr>
                    <th class="" width="5%">Sección</th>

                    <th v-for="subject in subjects.filter(e => e.level === semestre)" class="materias ui-widget-header ui-corner-all" width="14%">
                        <span class="materia-nombre" style="display: inline;">{{subject.name}}</span>
                    </th>
<!--                     <th class="materias ui-widget-header ui-corner-all" width="14%">
                        <span class="materia-nombre" style="display: inline;">Formaci�n Constitucional</span>
                        <span class="materia-avr" style="display: none;">For.Cons.</span> 
                    </th>
                    <th class="materias ui-widget-header ui-corner-all" width="14%">
                        <span class="materia-nombre" style="display: inline;">Fundamentos de la Inform�tica</span>
                        <span class="materia-avr" style="display: none;">Fun.Inf.</span>
                    </th>
                    <th class="materias ui-widget-header ui-corner-all" width="14%">
                        <span class="materia-nombre" style="display: inline;">Ingles I</span>
                        <span class="materia-avr" style="display: none;">Ing.I</span>
                    </th>
                    <th class="materias ui-widget-header ui-corner-all" width="14%">
                        <span class="materia-nombre" style="display: inline;">Lenguaje y Comunicaci�n</span>
                        <span class="materia-avr" style="display: none;">LyC</span>
                    </th>
                    <th class="materias ui-widget-header ui-corner-all" width="14%">
                        <span class="materia-nombre" style="display: inline;">Logica Matematica</span>
                        <span class="materia-avr" style="display: none;">Log.Mat.</span>
                    </th>
                    <th class="materias ui-widget-header ui-corner-all" width="14%">
                        <span class="materia-nombre" style="display: inline;">Matematica I</span>
                        <span class="materia-avr" style="display: none;">Mat.I</span>
                    </th>     -->                    
                </tr>
            </thead>
                        
            <tbody>
                <tr v-for="section in sections.filter(e => e.subject.level == semestre && e)">
                    <td class="secciones ui-widget-header ui-corner-all" width="5%">
                        <div style="font-size:2em;">1</div>
                        <div style="font-size:0.7em;"><!-- turno -->&nbsp;</div>
                    </td>
                    
                    <td class="ui-widget-content ui-corner-all">                                                
                        <!-- DOCENTES -->
                        <div class="docentes">                                                                                                                                                   
                            <div>
                                <span class="docente-completo" style="display: inline;"><strong>Argenis A Mendoza</strong></span>
                                <span class="docente-min" style="display: none;"><strong>A. Mendoza</strong></span>
                                <span class="docente-oculto" style="display: none;">&nbsp;</span>
                            </div>
                        </div>
                        <!-- FIN DOCENTES -->


                        <!-- ENCUENTROS -->
                        <div class="encuentros">
                            <div style="font-size:0.8em">
                                <!-- DIAS -->
                                <span class="dia-comp" style="display: inline;">Jueves</span>
                                <span class="dia-avr" style="display: none;">Ju</span>

                                <!-- AULA -->
                                : D / 
                                <!-- HORAS -->
                                <span class="hora-normal" style="display: inline;">07:45am - 09:20am</span>
                                <span class="hora-numero" style="display: none;">2 - 3</span>
                                <span class="hora-mil" style="display: none;">07:45 - 09:20</span>

                                <!-- CHOQUE DE HORARIOS -->
                                <span class="hidden" title="Choque de Horarios" style="cursor:pointer;">⊗</span>
                            </div>
                        </div>
                        <!-- FIN ENCUENTROS -->

                        <!-- CUPOS -->
                        <div class="cupo" style="font-size:0.8em">
                            <span class="cupo-completo" style="display: inline;">Cupo: 10</span>
                            <span class="cupo-oculto" style="display: none;"></span>
                        </div>
                        <!-- Fin CUPOS -->

                        <!-- BARRA DE HERRAMIENTAS POR SECCION -->
                        <!-- <div class="herramientas no-print">
                            <span class="abrir-formulario">
                                <a href="/seccions/edit/806/1" title="Modificar Datos de la Sección"><span class="ui-icon ui-icon-pencil" style="float:left; margin-right: .3em;" title=""></span></a>                                                    </span>
                            <span class="acciones">
                                                                                    </span>
                        </div> -->
                        <!-- Fin BARRA DE HERRAMIENTAS POR SECCION -->
                    </td>
                                        

                                                                                                                        <td class="ui-widget-content ui-corner-all">
                                                
                                                <!-- DOCENTES -->
                                                <div class="docentes">
                                                                                                                                                            <div>
                                                            <span class="docente-completo" style="display: inline;"><strong>Jhonny Gabazutt</strong></span>
                                                            <span class="docente-min" style="display: none;"><strong>J. Gabazutt</strong></span>
                                                            <span class="docente-oculto" style="display: none;">&nbsp;</span>
                                                        </div>
                                                                                                                                                    </div>
                                                <!-- FIN DOCENTES -->


                                                <!-- ENCUENTROS -->
                                                <div class="encuentros">
                                                                                                                                                                                                                                                        <div style="font-size:0.8em">
                                                                                    <!-- DIAS -->
                                                                                    <span class="dia-comp" style="display: inline;">Lunes</span>
                                                                                    <span class="dia-avr" style="display: none;">Lu</span>

                                                                                    <!-- AULA -->
                                                                                    : 14 / 
                                                                                    <!-- HORAS -->
                                                                                    <span class="hora-normal" style="display: inline;">07:00am - 08:30am</span>
                                                                                    <span class="hora-numero" style="display: none;">1 - 2</span>
                                                                                    <span class="hora-mil" style="display: none;">07:00 - 08:30</span>

                                                                                                                                                                        <!-- CHOQUE DE HORARIOS -->
                                                                                    <span class="no-print" title="Choque de Horarios" style="cursor:pointer;">⊗</span>
                                                                                    
                                                                                </div>
                                                            
                                                                                                                                                            </div>
                                                <!-- FIN ENCUENTROS -->

                                                <!-- CUPOS -->
                                                <div class="cupo" style="font-size:0.8em">
                                                    <span class="cupo-completo" style="display: inline;">Cupo: 10</span>
                                                    <span class="cupo-oculto" style="display: none;"></span>
                                                </div>
                                                <!-- Fin CUPOS -->

                                                <!-- BARRA DE HERRAMIENTAS POR SECCION -->
                                                <div class="herramientas no-print">
                                                    <span class="abrir-formulario">
                                                        <a href="/seccions/edit/811/1" title="Modificar Datos de la Sección"><span class="ui-icon ui-icon-pencil" style="float:left; margin-right: .3em;" title=""></span></a>                                                    </span>
                                                    <span class="acciones">
                                                                                                            </span>
                                                </div>
                                                <!-- Fin BARRA DE HERRAMIENTAS POR SECCION -->                                        


                                            </td>
                                        

                                                                                                                        <td class="ui-widget-content ui-corner-all">
                                                
                                                <!-- DOCENTES -->
                                                <div class="docentes">
                                                                                                                                                            <div>
                                                            <span class="docente-completo" style="display: inline;"><strong>Maria Magallanes</strong></span>
                                                            <span class="docente-min" style="display: none;"><strong>M. Magallanes</strong></span>
                                                            <span class="docente-oculto" style="display: none;">&nbsp;</span>
                                                        </div>
                                                                                                                                                    </div>
                                                <!-- FIN DOCENTES -->


                                                <!-- ENCUENTROS -->
                                                <div class="encuentros">
                                                                                                                                                                                                                                                        <div style="font-size:0.8em">
                                                                                    <!-- DIAS -->
                                                                                    <span class="dia-comp" style="display: inline;">Martes</span>
                                                                                    <span class="dia-avr" style="display: none;">Ma</span>

                                                                                    <!-- AULA -->
                                                                                    : 14 / 
                                                                                    <!-- HORAS -->
                                                                                    <span class="hora-normal" style="display: inline;">07:00am - 08:30am</span>
                                                                                    <span class="hora-numero" style="display: none;">1 - 2</span>
                                                                                    <span class="hora-mil" style="display: none;">07:00 - 08:30</span>

                                                                                    
                                                                                </div>
                                                            
                                                                                                                                                                                                                                                                                                                <div style="font-size:0.8em">
                                                                                    <!-- DIAS -->
                                                                                    <span class="dia-comp" style="display: inline;">Jueves</span>
                                                                                    <span class="dia-avr" style="display: none;">Ju</span>

                                                                                    <!-- AULA -->
                                                                                    : 14 / 
                                                                                    <!-- HORAS -->
                                                                                    <span class="hora-normal" style="display: inline;">07:00am - 08:30am</span>
                                                                                    <span class="hora-numero" style="display: none;">1 - 2</span>
                                                                                    <span class="hora-mil" style="display: none;">07:00 - 08:30</span>

                                                                                                                                                                        <!-- CHOQUE DE HORARIOS -->
                                                                                    <span class="no-print" title="Choque de Horarios" style="cursor:pointer;">⊗</span>
                                                                                    
                                                                                </div>
                                                            
                                                                                                                                                            </div>
                                                <!-- FIN ENCUENTROS -->

                                                <!-- CUPOS -->
                                                <div class="cupo" style="font-size:0.8em">
                                                    <span class="cupo-completo" style="display: inline;">Cupo: 10</span>
                                                    <span class="cupo-oculto" style="display: none;"></span>
                                                </div>
                                                <!-- Fin CUPOS -->

                                                <!-- BARRA DE HERRAMIENTAS POR SECCION -->
                                                <div class="herramientas no-print">
                                                    <span class="abrir-formulario">
                                                        <a href="/seccions/edit/815/1" title="Modificar Datos de la Sección"><span class="ui-icon ui-icon-pencil" style="float:left; margin-right: .3em;" title=""></span></a>                                                    </span>
                                                    <span class="acciones">
                                                                                                            </span>
                                                </div>
                                                <!-- Fin BARRA DE HERRAMIENTAS POR SECCION -->                                        


                                            </td>
                                        

                                                                                                                        <td class="ui-widget-content ui-corner-all">
                                                
                                                <!-- DOCENTES -->
                                                <div class="docentes">
                                                                                                                                                            <div>
                                                            <span class="docente-completo" style="display: inline;"><strong>Elizabeth Cusati</strong></span>
                                                            <span class="docente-min" style="display: none;"><strong>E. Cusati</strong></span>
                                                            <span class="docente-oculto" style="display: none;">&nbsp;</span>
                                                        </div>
                                                                                                                                                    </div>
                                                <!-- FIN DOCENTES -->


                                                <!-- ENCUENTROS -->
                                                <div class="encuentros">
                                                                                                                                                                                                                                                        <div style="font-size:0.8em">
                                                                                    <!-- DIAS -->
                                                                                    <span class="dia-comp" style="display: inline;">Lunes</span>
                                                                                    <span class="dia-avr" style="display: none;">Lu</span>

                                                                                    <!-- AULA -->
                                                                                    : 1 / 
                                                                                    <!-- HORAS -->
                                                                                    <span class="hora-normal" style="display: inline;">07:00am - 08:30am</span>
                                                                                    <span class="hora-numero" style="display: none;">1 - 2</span>
                                                                                    <span class="hora-mil" style="display: none;">07:00 - 08:30</span>

                                                                                                                                                                        <!-- CHOQUE DE HORARIOS -->
                                                                                    <span class="no-print" title="Choque de Horarios" style="cursor:pointer;">⊗</span>
                                                                                    
                                                                                </div>
                                                            
                                                                                                                                                            </div>
                                                <!-- FIN ENCUENTROS -->

                                                <!-- CUPOS -->
                                                <div class="cupo" style="font-size:0.8em">
                                                    <span class="cupo-completo" style="display: inline;">Cupo: 10</span>
                                                    <span class="cupo-oculto" style="display: none;"></span>
                                                </div>
                                                <!-- Fin CUPOS -->

                                                <!-- BARRA DE HERRAMIENTAS POR SECCION -->
                                                <div class="herramientas no-print">
                                                    <span class="abrir-formulario">
                                                        <a href="/seccions/edit/818/1" title="Modificar Datos de la Sección"><span class="ui-icon ui-icon-pencil" style="float:left; margin-right: .3em;" title=""></span></a>                                                    </span>
                                                    <span class="acciones">
                                                                                                            </span>
                                                </div>
                                                <!-- Fin BARRA DE HERRAMIENTAS POR SECCION -->                                        


                                            </td>
                                        

                                                                                                                        <td class="ui-widget-content ui-corner-all">
                                                
                                                <!-- DOCENTES -->
                                                <div class="docentes">
                                                                                                                                                            <div>
                                                            <span class="docente-completo" style="display: inline;"><strong>Tibisay Duarte</strong></span>
                                                            <span class="docente-min" style="display: none;"><strong>T. Duarte</strong></span>
                                                            <span class="docente-oculto" style="display: none;">&nbsp;</span>
                                                        </div>
                                                                                                                                                    </div>
                                                <!-- FIN DOCENTES -->


                                                <!-- ENCUENTROS -->
                                                <div class="encuentros">
                                                                                                                                                                                                                                                        <div style="font-size:0.8em">
                                                                                    <!-- DIAS -->
                                                                                    <span class="dia-comp" style="display: inline;">Lunes</span>
                                                                                    <span class="dia-avr" style="display: none;">Lu</span>

                                                                                    <!-- AULA -->
                                                                                    : 14 / 
                                                                                    <!-- HORAS -->
                                                                                    <span class="hora-normal" style="display: inline;">10:10am - 11:40am</span>
                                                                                    <span class="hora-numero" style="display: none;">5 - 6</span>
                                                                                    <span class="hora-mil" style="display: none;">10:10 - 11:40</span>

                                                                                    
                                                                                </div>
                                                            
                                                                                                                                                            </div>
                                                <!-- FIN ENCUENTROS -->

                                                <!-- CUPOS -->
                                                <div class="cupo" style="font-size:0.8em">
                                                    <span class="cupo-completo" style="display: inline;">Cupo: 10</span>
                                                    <span class="cupo-oculto" style="display: none;"></span>
                                                </div>
                                                <!-- Fin CUPOS -->

                                                <!-- BARRA DE HERRAMIENTAS POR SECCION -->
                                                <div class="herramientas no-print">
                                                    <span class="abrir-formulario">
                                                        <a href="/seccions/edit/821/1" title="Modificar Datos de la Sección"><span class="ui-icon ui-icon-pencil" style="float:left; margin-right: .3em;" title=""></span></a>                                                    </span>
                                                    <span class="acciones">
                                                                                                            </span>
                                                </div>
                                                <!-- Fin BARRA DE HERRAMIENTAS POR SECCION -->                                        


                                            </td>
                                        

                                                                                                                        <td class="ui-widget-content ui-corner-all">
                                                
                                                <!-- DOCENTES -->
                                                <div class="docentes">
                                                                                                                                                            <div>
                                                            <span class="docente-completo" style="display: inline;"><strong>Adriana Urbaez</strong></span>
                                                            <span class="docente-min" style="display: none;"><strong>A. Urbaez</strong></span>
                                                            <span class="docente-oculto" style="display: none;">&nbsp;</span>
                                                        </div>
                                                                                                                                                    </div>
                                                <!-- FIN DOCENTES -->


                                                <!-- ENCUENTROS -->
                                                <div class="encuentros">
                                                                                                                                                                                                                                            <div class="no-print" style="font-size:0.8em">
                                                                        <span class="dia-comp ui-state-error" style="display: inline;"> Encuentro no Asignado</span>
                                                                        <span class="dia-avr ui-state-error" style="display: none;"> Encuentro: n/a</span>
                                                                    </div>
                                                                    <div class="no-screen" style="font-size:0.8em">&nbsp;&nbsp;Encuentro: n/a</div>
                                                            
                                                                                                                                                                                                                                                                                                                <div style="font-size:0.8em">
                                                                                    <!-- DIAS -->
                                                                                    <span class="dia-comp" style="display: inline;">Jueves</span>
                                                                                    <span class="dia-avr" style="display: none;">Ju</span>

                                                                                    <!-- AULA -->
                                                                                    : 14 / 
                                                                                    <!-- HORAS -->
                                                                                    <span class="hora-normal" style="display: inline;">08:35am - 10:05am</span>
                                                                                    <span class="hora-numero" style="display: none;">3 - 4</span>
                                                                                    <span class="hora-mil" style="display: none;">08:35 - 10:05</span>

                                                                                                                                                                        <!-- CHOQUE DE HORARIOS -->
                                                                                    <span class="no-print" title="Choque de Horarios" style="cursor:pointer;">⊗</span>
                                                                                    
                                                                                </div>
                                                            
                                                                                                                                                            </div>
                                                <!-- FIN ENCUENTROS -->

                                                <!-- CUPOS -->
                                                <div class="cupo" style="font-size:0.8em">
                                                    <span class="cupo-completo" style="display: inline;">Cupo: 10</span>
                                                    <span class="cupo-oculto" style="display: none;"></span>
                                                </div>
                                                <!-- Fin CUPOS -->

                                                <!-- BARRA DE HERRAMIENTAS POR SECCION -->
                                                <div class="herramientas no-print">
                                                    <span class="abrir-formulario">
                                                        <a href="/seccions/edit/823/1" title="Modificar Datos de la Sección"><span class="ui-icon ui-icon-pencil" style="float:left; margin-right: .3em;" title=""></span></a>                                                    </span>
                                                    <span class="acciones">
                                                                                                            </span>
                                                </div>
                                                <!-- Fin BARRA DE HERRAMIENTAS POR SECCION -->                                        


                                            </td>
                                        

                                                                                                                        <td class="ui-widget-content ui-corner-all">
                                                
                                                <!-- DOCENTES -->
                                                <div class="docentes">
                                                                                                                                                            <div>
                                                            <span class="docente-completo" style="display: inline;"><strong>Florencio Carre�o</strong></span>
                                                            <span class="docente-min" style="display: none;"><strong>F. Carre�o</strong></span>
                                                            <span class="docente-oculto" style="display: none;">&nbsp;</span>
                                                        </div>
                                                                                                                                                    </div>
                                                <!-- FIN DOCENTES -->


                                                <!-- ENCUENTROS -->
                                                <div class="encuentros">
                                                                                                                                                                                                                                                        <div style="font-size:0.8em">
                                                                                    <!-- DIAS -->
                                                                                    <span class="dia-comp" style="display: inline;">Miercoles</span>
                                                                                    <span class="dia-avr" style="display: none;">Mi</span>

                                                                                    <!-- AULA -->
                                                                                    : 14 / 
                                                                                    <!-- HORAS -->
                                                                                    <span class="hora-normal" style="display: inline;">07:00am - 09:20am</span>
                                                                                    <span class="hora-numero" style="display: none;">1 - 3</span>
                                                                                    <span class="hora-mil" style="display: none;">07:00 - 09:20</span>

                                                                                    
                                                                                </div>
                                                            
                                                                                                                                                                                                                                                                                                                <div style="font-size:0.8em">
                                                                                    <!-- DIAS -->
                                                                                    <span class="dia-comp" style="display: inline;">Viernes</span>
                                                                                    <span class="dia-avr" style="display: none;">Vi</span>

                                                                                    <!-- AULA -->
                                                                                    : 14 / 
                                                                                    <!-- HORAS -->
                                                                                    <span class="hora-normal" style="display: inline;">07:00am - 09:20am</span>
                                                                                    <span class="hora-numero" style="display: none;">1 - 3</span>
                                                                                    <span class="hora-mil" style="display: none;">07:00 - 09:20</span>

                                                                                    
                                                                                </div>
                                                            
                                                                                                                                                            </div>
                                                <!-- FIN ENCUENTROS -->

                                                <!-- CUPOS -->
                                                <div class="cupo" style="font-size:0.8em">
                                                    <span class="cupo-completo" style="display: inline;">Cupo: 10</span>
                                                    <span class="cupo-oculto" style="display: none;"></span>
                                                </div>
                                                <!-- Fin CUPOS -->

                                                <!-- BARRA DE HERRAMIENTAS POR SECCION -->
                                                <div class="herramientas no-print">
                                                    <span class="abrir-formulario">
                                                        <a href="/seccions/edit/828/1" title="Modificar Datos de la Sección"><span class="ui-icon ui-icon-pencil" style="float:left; margin-right: .3em;" title=""></span></a>                                                    </span>
                                                    <span class="acciones">
                                                                                                            </span>
                                                </div>
                                                <!-- Fin BARRA DE HERRAMIENTAS POR SECCION -->                                        


                                            </td>
                                        

                </tr>
                
            </tbody>
        </table>
    </div>     
  </MyLayout>
    
    
</template>